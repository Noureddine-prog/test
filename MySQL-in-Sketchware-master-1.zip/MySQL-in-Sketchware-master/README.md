# MySQL in Sketchware
In this repostiory you will find files which are helpfull to connect, send and retrive data from MySQL using PHP through Sketchware app.

